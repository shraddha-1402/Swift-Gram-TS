export namespace Theme {
  export enum Mode {
    dark = "dark",
    light = "light",
  }

  export type State = {
    mode: keyof typeof Mode;
  };
}

export namespace Auth {
  export type User = {
    _id: string;
    firstName: string;
    lastName: string;
    username: string;
    password?: string;
    createdAt: string;
    updatedAt: string;
    bio: string;
    avatarURL: string;
    bookmarks: string[];
  };
  export type LoginData = {
    token: string | null;
    user: User | null;
  };

  export interface State {
    token: string | null;
    user: User | null;
    isAuthLoading: boolean;
    isAuthContentLoading: boolean;
  }
}
